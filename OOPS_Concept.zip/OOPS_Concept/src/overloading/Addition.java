package overloading;

class Addition{
	
	void AddNumber(int x,int y){
		
		int AddNum = x+y;
		System.out.println("Result is " + AddNum);
	}
	
	void AddNumber(int x,double y,float z){
		
		double Result = x+y+z;
		
		System.out.println("Result is " + Result);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Addition add =new Addition();
		
		add.AddNumber(10, 20);
		add.AddNumber(20, 20, 30.125f);

	}
}
