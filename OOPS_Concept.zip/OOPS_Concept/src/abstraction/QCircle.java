package abstraction;

public class QCircle extends HCircle{
	double radius;
    
    public QCircle(String color,double radius) {
        super(color, radius);
    	System.out.println("Quarter constructor called");
        // calling Shape constructor
        //super(color);
    	this.color=color;
        
        this.radius = radius;
    }
 
    @Override
    double area() {
        return ( Math.PI * Math.pow(radius, 2) ) / 4;
    }
 
    String qChild() {
    	return "new method at qbit level";
    }
    
    @Override
    public String toString() {
        return "QCircle color is " + this.color + 
                       " and area is : " + this.area();
    }
}
