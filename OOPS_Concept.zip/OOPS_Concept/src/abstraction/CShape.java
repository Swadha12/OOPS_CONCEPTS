package abstraction;

public class CShape {

    String color;
     
    // these are abstract methods
   
    public void ToString(){
    	System.out.println("inside super class shape");
    }
     
    // abstract class can have constructor
    public CShape(String color) {
        System.out.println("Shape constructor called");
        this.color = color;
    }
     
    // this is a concrete method
    public String getColor() {
        return color;
    }
    
    double area() {
    	System.out.println("Cshape area");
		return 0.00;
    }

}
