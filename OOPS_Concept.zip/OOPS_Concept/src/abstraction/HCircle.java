package abstraction;

public class HCircle extends Circle {
	double radius;
    
    public HCircle(String color,double radius) {
        super(color, radius);
    	System.out.println("Half constructor called");
        // calling Shape constructor
        //super(color);
    	this.color=color;
        
        this.radius = radius;
    }
 
    @Override
    double area() {
        return ( Math.PI * Math.pow(radius, 2) ) / 2;
    }
    
    String hChild() {
    	return "new method at hbit level";
    }
 
    @Override
    public String toString() {
        return "HCircle color is " + this.color + 
                       " and area is : " + this.area();
    }
 
}
