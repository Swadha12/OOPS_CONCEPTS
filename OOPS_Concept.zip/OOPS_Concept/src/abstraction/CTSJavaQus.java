package abstraction;

public class CTSJavaQus {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// pom.xml structure
		// testng.xml structure
		// soap and rest proptocol difference
		// what is rest assured how it works
		// write a testng class with minimum 5 annotation used
		// java memory management with variables
		// exception hierachy
		// collection class in java
		// write
		/*
		 * String s1="abc"; String s2="abz";
		 * 
		 * String s3 = "xyz"; String s4 = new String(); s4="abc"; String s5 = s1;
		 * 
		 * 
		 * System.out.println(s1 ); System.out.println(s2); System.out.println(s3);
		 * System.out.println(s4); System.out.println(s5);
		 * 
		 * System.out.println(s1 == s2); System.out.println(s1.equals("abc"));
		 * System.out.println(s1 == s3); System.out.println(s1.equals(s3));
		 * System.out.println(s1 == s4); System.out.println(s1.equals(s4));
		 * System.out.println(s1 == s5); System.out.println(s1.equals(s5));
		 */

		String s1 = "Arsalan"; //primitive
		String s2 = "Arsalan"; //primitives

		String s3 = new String("Arsalan"); //object

		if (s1 == s2) //Only Reference check //HARD Check. Reference check make value checking redundant
			System.out.println("1: S1 and S2 Both are equal...");
		else
			System.out.println("1: S1 and S2 not equal");

		if (s1 == s3)
			System.out.println("2: S1 and S3 Both are equal...");
		else
			System.out.println("2: S1 and S3 are not equal");

		if (s1.equals(s2))
			System.out.println("3: S1 and S2 Both are equal...");
		else
			System.out.println("3: S1 and S2 not equal");

		if (s1.equals(s3))
			System.out.println("4:  S1 and S3 Both are equal...");
		else
			System.out.println("4:  S1 and S3 are not equal");

	}

}
