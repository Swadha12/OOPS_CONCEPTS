package abstraction;

class Circle extends CShape
{
    double radius;
     
    public Circle(String color,double radius) {
        super(color);
    	System.out.println("Circle constructor called");
        // calling Shape constructor
        //super(color);
    	this.color=color;
        
        this.radius = radius;
    }
 
    @Override
    double area() {
        return Math.PI * Math.pow(radius, 2);
    }
 
    @Override
    public String toString() {
        return "Circle color is " + this.color + 
                       " and area is : " + this.area();
    }
  
/*    @Override
  public void ToString() {
      System.out.println("inside circle child method");
  }
*/    
    
}
