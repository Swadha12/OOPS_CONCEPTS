package abstraction;

class Rectangle extends CShape{
	 
    double length;
    double width;
    String name = "Rectangle"; 
    public Rectangle(String color,double length,double width) {
        // calling Shape constructor
        super(color);
        System.out.println("Rectangle constructor called");
        this.length = length;
        this.width = width;
    }
     
    @Override
    double area() {
        return length*width;
    }
 
    @Override
    public String toString() {
        return "Rectangle color is " + this.color + 
                           " and area is : " + this.area();
    }
 
}