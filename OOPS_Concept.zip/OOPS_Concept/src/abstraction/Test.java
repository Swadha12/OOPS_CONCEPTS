package abstraction;

import java.util.*;


public class Test 
{
    public static void main(String[] args)
    {
    	
/*    	 Integer[] arr= {6,8,4,5,7,9,10,11,12,13,14,15};
    	 Arrays.sort(arr, Collections.reverseOrder() );
    	 System.out.println(Arrays.toString(arr));
    	 int index=Arrays.binarySearch(arr, 9);
    	 System.out.println(index);*/
    	 
    	 
/*        CShape s1 = new Circle("red", 2.2);
        CShape s2 = new Rectangle("yellow", 2, 4);
        
        CShape s3= new CShape("red3"); 
        Circle c11 = new Circle("red11", 3);
        
        CShape s4 = new CShape("yellow4");
        Rectangle r11 = new Rectangle("yellow11", 3, 7);
        
        s3 = c11;	 Upcasting or Narrow casting  
        System.out.println(s3.area());
        Circle c111 = (Circle) s3;  Downcasting/widening of the above narrow casting  
        
        System.out.println(c111.area());
        
        Rectangle r111 = (Rectangle) s4;   //down
        System.out.println(r111.area());
        CShape s5 = r111;          //up
        System.out.println(s5.area());
        
        s1.ToString();
        s2.ToString();*/
        
        CShape sfc1 = new Circle("fc1", 7);
        System.out.println(sfc1.area());
        CShape shc1 = new HCircle("hc1", 7);
        System.out.println(shc1.area());
        CShape sqc1 = new QCircle("qc1", 7);
        System.out.println(sqc1.area());
        CShape sqc3 = new QCircle("qc3", 777);
        CShape sqc2 = new QCircle("qc2", 7);
        System.out.println("castint calculation start");
        
        QCircle sqc4 = (QCircle) sqc1;
        System.out.println("Calling...: " + sqc4.qChild() );
        
        
/*        Circle sfc2 = (Circle) shc1;
        System.out.println("circle area");
        System.out.println(sfc2.area());
        
        System.out.println("Half circle area");
        HCircle shc2 = (HCircle) sqc1;
        System.out.println(shc2.area());
        
        //HCircle shc3 = sfc2;
        System.out.println(" Quarter circle area");
        QCircle sqc2 =(QCircle) shc3;
        System.out.println(sqc2.area());*/
        
        
        
        
/*        System.out.println(" New Quarter circle area");
        //QCircle sqc2 =(QCircle) sqc3;
        sqc2 =(QCircle) sqc3;
        System.out.println(sqc2.area());   

        System.out.println("Q1 38... circle area");
        HCircle shc2 = (HCircle) sqc2;
        System.out.println(shc2.area());
        
        System.out.println("Half 76...");
        Circle sfc2 = (Circle) shc2;
        System.out.println(sfc2.area());*/
        

        
       
        
        
        
        
    }

}
