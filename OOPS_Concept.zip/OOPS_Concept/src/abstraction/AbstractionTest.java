package abstraction;

public abstract class AbstractionTest {

	private static int empid;
	private  static String empName;
	
	public abstract void getId();
	
	public static String getName() {
		
		
		return empName;

	}

	/**
	 * @return the empid
	 */
	public static int getEmpid() {
		return empid;
	}

	/**
	 * @param empid the empid to set
	 */
	public static void setEmpid(int empid) {
		AbstractionTest.empid = empid;
	}

}
