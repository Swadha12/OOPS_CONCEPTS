package encapsulation;

public class Encapsulate {
	 // private variables declared 
    // these can only be accessed by 
    // public methods of class
    private String empName;
    private int empRoll;
    private int empAge;
 
    // get method for age to access 
    // private variable geekAge
    public int getAge() 
    {
      return empAge;
    }
  
    // get method for name to access 
    // private variable geekName
    public String getName() 
    {
      return empName;
    }
     
    // get method for roll to access 
    // private variable geekRoll
    public int getRoll() 
    {
       return empRoll;
    }
  
    // set method for age to access 
    // private variable geekage
    public void setAge( int newAge)
    {
      empAge = newAge;
    }
  
    // set method for name to access 
    // private variable geekName
    public void setName(String newName)
    {
      empName = newName;
    }
     
    // set method for roll to access 
    // private variable geekRoll
    public void setRoll( int newRoll) 
    {
      empRoll = newRoll;
    }
}
