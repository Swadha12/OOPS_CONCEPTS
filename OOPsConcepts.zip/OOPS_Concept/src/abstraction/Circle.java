package abstraction;

class Circle extends Shape
{
    double radius;
     
    public Circle(String color,double radius) {
        super(color);
    	System.out.println("Circle constructor called");
        // calling Shape constructor
        //super(color);
    	this.color=color;
        
        this.radius = radius;
    }
 
    @Override
    double area() {
        return Math.PI * Math.pow(radius, 2);
    }
 
//    @Override
//    public String toString() {
//        return "Circle color is " + super.color + 
//                       " and area is : " + area();
//    }
  
    @Override
  public void ToString() {
      System.out.println("inside child method");
  }
    
}
