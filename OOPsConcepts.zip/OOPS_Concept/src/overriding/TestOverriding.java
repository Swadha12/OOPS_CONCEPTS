package overriding;

public class TestOverriding {


		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			OnlineDiscount on;
			OnlineDiscount on1;
			
			on = new Amazon();
			
			System.out.println("Amazon discount is " + on.Discount(10));
			
			on = new Flipkart();
			
			System.out.println("Flipkart discount is " + on.Discount(20));
			
			//on =
			

		}
 
	}
