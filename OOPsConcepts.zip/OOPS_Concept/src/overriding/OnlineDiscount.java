package overriding;

class OnlineDiscount{
	
	int Discount(int x){
		
		return 10;
		
	}
}