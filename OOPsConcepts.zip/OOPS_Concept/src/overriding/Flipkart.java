package overriding;

class Flipkart extends Amazon{
	
	int Discount(int z){
		
		return 35;
	}
}
