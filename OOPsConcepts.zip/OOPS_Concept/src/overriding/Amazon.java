package overriding;

class Amazon extends OnlineDiscount{
	
	int Discount(int y){
		
		return y;
	}
}

