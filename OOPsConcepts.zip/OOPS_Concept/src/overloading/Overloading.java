package overloading;

public class Overloading {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Addition add =new Addition();
		
		add.AddNumber(10, 20);
		add.AddNumber(20, 20, 30.125f);

	}
}
